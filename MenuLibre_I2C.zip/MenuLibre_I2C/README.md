# MenuLibrary

Diese Bibliothek ermöglicht es, Menüs auf einem LCD-Display zu erstellen und zu navigieren.

## Abhängigkeiten

- **Wire**: Wird für die I2C-Kommunikation benötigt (ist in der Arduino-Standardbibliothek enthalten).
- **LiquidCrystal_I2C**: Eine I2C-basierte LCD-Bibliothek. Installiere sie über den Bibliotheksmanager der Arduino IDE:
  - Gehe zu **Werkzeuge** → **Bibliotheken verwalten** → Suche nach `LiquidCrystal I2C` und installiere die Bibliothek von **Frank de Brabander**.
# MenuLibrary
